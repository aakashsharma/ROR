# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Mailerapp::Application.config.secret_token = 'd596e43cdc894f129ad4798dfe5c511eb96c2062319fe964e7e11f09d8e00680f418637619d63f03f8a977a1129b7480bc6bd38b96f5b90575bab72b273d2860'
